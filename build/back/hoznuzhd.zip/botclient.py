# coding: utf-8
from __future__ import absolute_import, with_statement, print_function, unicode_literals

__version__ = '20.272.2127'  # gzip_decode
#__version__ = '20.260.0040'  # binary
#__version__ = '20.136.1222'
#__version__ = '20.104.0843'
#__version__ = '20.053.0012'
#__version__ = '20.026.2002'
#__version__ = '20.022.0456'
#__version__ = '19.347.0205'

import sys
PY2 = sys.version_info[0] < 3
PY3 = sys.version_info[0] > 2
if __name__ == '__main__':
    # env PYTHONIOENCODING="UTF-8"
    if PY2:
        reload(sys); sys.setdefaultencoding('UTF-8')
    else:
        if sys.stdout.encoding != 'UTF-8':
            sys.stdout = open(sys.stdout.fileno(), mode='w', buffering=1, encoding='UTF-8')
        #if sys.stderr.encoding != 'UTF-8':
        #    sys.stderr = open(sys.stderr.fileno(), mode='w', buffering=1, encoding='UTF-8')
    sys.stderr.close()
    sys.stderr = sys.stdout
import socket
try:
    __hostname__ = sys.__hostname__
except:
    __hostname__ = socket.gethostname().lower()
    sys.__hostname__ = __hostname__
if PY2:
    import ConfigParser as configparser
    input = raw_input
    from urllib import quote_plus, unquote_plus, urlencode
    from urlparse import urlparse
    BrokenPipeError = socket.error
    ConnectionRefusedError = socket.error
    from xmlrpclib import gzip_decode, gzip_encode
else:
    import configparser
    raw_input = input
    from urllib.parse import quote_plus, unquote_plus, urlencode, urlparse
    from xmlrpc.client import gzip_decode, gzip_encode
    unicode = str

import os, time, json  #, pickle
from threading import Thread, RLock, Event
if PY2:
    from Queue import Queue, Empty
else:
    from queue import Queue, Empty

import pydoc
import threading, types, traceback
import uuid, hashlib, base64
import random

import decimal, datetime
class ExtJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        #if isinstance(obj, Binary):
        #    return {'__binary__': obj.encode()}
        if isinstance(obj, decimal.Decimal):
            return float(obj)
        elif isinstance(obj, datetime.datetime):
            return str(obj)
        elif isinstance(obj, datetime.date):
            return str(obj)
        elif isinstance(obj, set):
            return list(obj)
        #print('obj:', obj)
        return json.JSONEncoder.default(self, obj)

try:
    from types import SimpleNamespace
except ImportError:
    class SimpleNamespace (object):
        def __init__ (self, **kwargs):
            self.__dict__.update(kwargs)
        def __repr__ (self):
            keys = sorted(self.__dict__)
            items = ("{}={!r}".format(k, self.__dict__[k]) for k in keys)
            return "{}({})".format(type(self).__name__, ", ".join(items))
        def __eq__ (self, other):
            return self.__dict__ == other.__dict__
if PY2:
    Binary = lambda data: {'__binary__': base64.b64encode(data)}
else:
    Binary = lambda data: {'__binary__': base64.b64encode(data).decode('ascii')}
_binary = lambda obj: SimpleNamespace(data=base64.b64decode(obj.pop('__binary__'))) if '__binary__' in obj else obj

class ServiceError(RuntimeError):
    pass
class MethodError(RuntimeError):
    pass

class BOTProxy(object):

    def __init__(self, name, address=None, authkey=None):
        self._botname = name
        if address is None:
            address = ('127.0.0.1', 4222)
        self._address = address
        self._conn = BOTClient(name, address, authkey=authkey)
        #self._conn.start()

    def _close(self):
        return self._conn.close()

    def __call__(self, name, sync=True, bot=False):
        if bot:
            bot_id = 'bot.%s' % urn5(name)
            #log(bot_id, name)
            return _Method(self._conn, name, sync=sync, bot_id=bot_id)
        else:
            #if name == '.http':
            #    return self._conn.http
            if name == '.notify':
                return self._conn.notify
            elif name == '.conduit':
                return self._conn.conduit
            else:
                return _Method(self._conn, name, sync=sync, bot_id=None)

    def __repr__(self):
        return (
            "<%s for %s %s>" % (self.__class__.__name__, self._botname, self._address)
        )

    __str__ = __repr__

    def __getattr__(self, name):
        return _Method(self._conn, name, sync=True)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self._close()

class _Method(object):

    def __init__(self, conn, name, sync=True, bot_id=None):
        self.__conn = conn
        self.__send = conn.send
        if bot_id:
            self.__name = None
            self.__botname = name
        else:
            self.__name = name
            self.__botname = None
        self.__sync = sync
        self.__bot_id = bot_id

    def _set_botinfo(self, bot_id, botname):
        self.__bot_id = bot_id
        self.__botname = botname

    def __getattr__(self, name):
        if self.__name:
            _m = _Method(self.__conn, "%s.%s" % (self.__name, name), sync=self.__sync, bot_id=None)
        else:
            _m = _Method(self.__conn, name, sync=self.__sync, bot_id=None)
        if self.__bot_id:
            #print(dir(_m))
            _m._set_botinfo(self.__bot_id, self.__botname)
            #_m._Method__bot_id = self.__bot_id
            #_m._Method__botname = self.__botname
        return _m

    def __call__(self, *args, **kwarg):
        if self.__name:
            return self.__send(self.__name, args, kwarg, sync=self.__sync, bot_id=self.__bot_id, botname=self.__botname)
        elif self.__botname:
            #raise RuntimeError('BOT <%s> is not callable' % self.__botname)
            name = args[0]
            #if name == '.http':
            #    return self.__conn.http
            if name == '.notify':
                return self.__conn.notify
            elif name == '.conduit':
                return self.__conn.conduit
            else:
                sync = kwarg.get('sync', self.__sync)
                _m = _Method(self.__conn, name, sync=sync, bot_id=None)
                _m._set_botinfo(self.__bot_id, self.__botname)
                #_m._Method__bot_id = self.__bot_id
                #_m._Method__botname = self.__botname
                return _m


from weakref import WeakValueDictionary
class BOTClient(object):
    def __init__(self, name, address, authkey=None):
        self._sync = WeakValueDictionary()
        self._info = {}
        self._start = None
        self.cli_id = 'cli.%s' % uuid.uuid4().hex
        self._sock = None
        self._w_lck = RLock()
        self._fg_serve_forever = False
        self._botname = name
        self.bot_id = 'bot.%s' % urn5(self._botname)
        self._address = address
        self._authkey = authkey
        self._online = Event()
        self.start()

    def start(self):
        if self._start is None:
            _t = Thread(target=self.serve_forever)
            _t.daemon = True
            _t.name += '-BOTClient'
            _t.start()
            self._start = _t
        return self._start

    def close(self):
        self._fg_serve_forever = False
        self._start = None

    def serve_forever(self):
        self.close()
        _defer = []
        defer = _defer.append
        _err_old = ''
        _fg_loop = True
        while _fg_loop:
            _fg_loop = False
            try:
                self._run(defer)
                #except (KeyboardInterrupt, SystemExit) as e:
                #    log('stop', begin='\r')
            except (ConnectionRefusedError, RuntimeError) as e:
                #log('ERROR1', 'LOOP')
                _fg_loop = True
                _err = str(e)
                if _err_old != _err:
                    _err_old = _err
                    log(_err, kind='error1')
                try:
                    time.sleep(1 + random.random())
                except:
                    _fg_loop = False
                    pass
                    #log('stop', begin='\r')
            except Exception as e:
                #log('ERROR2', 'LOOP')
                _fg_loop = self._fg_serve_forever
                #traceback.print_exc()
                _err = str(e)
                if _err_old != _err:
                    _err_old = _err
                    #log(_err, kind='error2')
                    log(None)
            finally:
                self._online.clear()
                while _defer:
                    func = _defer.pop(-1)
                    try:
                        func()
                    except:
                        #log(None)
                        pass

    def conduit(self, names):
        if names:
            if not self._online.wait(5):
                raise RuntimeError('[ %s ] connect timeout' % str(self._address))
            """
            c = 0
            while not self._fg_serve_forever:
                c += 1
                if c > 10000:
                    raise RuntimeError('[ %s ] connect timeout' % str(self._address))
                time.sleep(0.001)
            """
            sub, unsub = [], []
            r = Queue()
            id_r = id(r)
            sid = '%%s.%x' % id_r
            #sid = 'event_%s_%%s' % uuid.uuid4().hex
            for i, name in enumerate(names, 3):
                cmd = 'SUB %s %s\r\n' % (name, sid % i)
                sub.append(cmd)
                cmd = 'UNSUB %s\r\n' % (sid % i)
                unsub.append(cmd)
                #print(cmd)
            sub = ''.join(sub).encode('utf8')
            unsub = ''.join(unsub).encode('utf8')
            #print('sub:', sub)
            #print('unsub:', unsub)
            self._sync[id_r] = r
            old_sock_id = id(self._sock)
            try:
                with self._w_lck:
                    self._sock.sendall(sub)
                while self._fg_serve_forever:
                    try:
                        obj = r.get(timeout=2)
                        r.task_done()
                        yield obj
                    except Empty:
                        yield (None, None)
                    new_sock_id = id(self._sock)
                    if old_sock_id != new_sock_id:
                        log('NEW SOCK!!!')
                        old_sock_id = new_sock_id
                        with self._w_lck:
                            self._sock.sendall(unsub)
                            self._sock.sendall(sub)
            finally:
                del self._sync[id_r]
                with self._w_lck:
                    try:
                        self._sock.sendall(unsub)
                    except:
                        pass
                #print('end:', r, names)
        #print(repr(sub))
        #print(repr(unsub))

    def notify(self, subject, data=None):
        if not self._fg_serve_forever:
            return
        if data is None:
            data = ('PUB %s 0\r\n\r\n' % subject).encode('utf8')
        else:
            data = json.dumps(data, ensure_ascii=False, cls=ExtJSONEncoder).encode('utf8')
            #data = pickle.dumps(data, protocol=2)
            if len(data) > 1400:
                data = gzip_encode(data)
            data = ('PUB %s %s\r\n' % (subject, len(data))).encode('utf8') + data + b'\r\n'
        with self._w_lck:
            try:
                self._sock.sendall(data)
                return True
            except:
                pass
                #traceback.print_exc()

    """
    def http(self, head, body):
        log(self, 'http')
        print(dir(self))
        for nm in ['_address', '_authkey', '_botname', '_fg_serve_forever', '_info', '_run', '_send', '_sock', '_start', '_sync', '_w_lck', 'bot_id', 'cli_id', 'close', 'conduit', 'http', 'notify', 'send', 'serve_forever', 'start']:
            print(nm, getattr(self, nm))
        return '200 OK', [('Content-type', 'text/plain; charset=utf-8')], 'Привет Мир!'.encode()
    """
    _send_count = 0
    def send(self, name, args, kwargs, sync=True, bot_id=None, botname=None):
        #print('send:', name, args, kwargs, sync, bot_id)
        if not bot_id:
            bot_id = self.bot_id
        if '.http' == name:
            #if len(args[1]) > 1400 and b'\x1f\x8b\x08\x00' != args[1][:4]:
            #    data = b''.join([b'HTTP', json.dumps(args[0], ensure_ascii=False, separators=(',', ':')).encode('utf8'),  b'\r\n', gzip_encode(args[1])])
            #else:
            data = b''.join([b'HTTP', json.dumps(args[0], ensure_ascii=False, separators=(',', ':')).encode('utf8'),  b'\r\n', args[1]])
        else:
            data = {'method': name, 'args': args, 'kwargs': kwargs}
            data = json.dumps(data, ensure_ascii=False, cls=ExtJSONEncoder).encode('utf8')
            if len(data) > 1400:
                data = gzip_encode(data)

        if not self._online.wait(5):
            raise RuntimeError('[ %s ] connect timeout' % str(self._address))
        """
        c = 0
        while not self._fg_serve_forever:
            c += 1
            if c > 10000:
                raise RuntimeError('[ %s ] connect timeout' % str(self._address))
            time.sleep(0.001)
        """

        r = Event()
        r.ask = False
        r.result = None
        r.error = None
        i = id(r)

        #cli, sid = 'cli.%s.%x' % (uuid.uuid4().hex, i), '1.%x' % i
        #cmd = ('SUB %(cli)s %(sid)s\r\nUNSUB %(sid)s 2\r\nPUB %(bot)s %(cli)s %(l)s\r\n%%s\r\n' % {'cli': cli, 'sid': sid, 'l': len(data), 'bot': bot_id}).encode()
        #print(cmd)
        #data = cmd % data

        data = ('PUB %s %s.%x %s\r\n' % (bot_id, self.cli_id, i, len(data))).encode('utf8') + data + b'\r\n'

        self._sync[i] = r
        err = None
        with self._w_lck:
            #self._send_count += 1
            try:
                #if 0 == self._send_count % 10:
                #    self._sock.close()
                #    raise ValueError('self._send_count: %s' % self._send_count)
                self._sock.sendall(data)
            except Exception as e:
                err = e
                #self.cli_id = 'cli.%s' % uuid.uuid4().hex
                self._sock.close()
                self._online.clear()
                log(None)
        if err:
            log('[ %s ] reconnect' % str(self._address))
            if not self._online.wait(5):
                raise RuntimeError('[ %s ] connect timeout' % str(self._address))
            with self._w_lck:
                self._sock.sendall(data)

        #print('self._send_count:', self._send_count, flush=True)
        if type(sync) in (list, tuple):
            _wait1, _wait2 = sync[:2]
        else:
            _wait1, _wait2 = 5, 40
        if r.wait(_wait1):
            r.clear()
        else:
            r.error = ServiceError('Service <%s> not found' % (botname if botname else self._botname))
            #with self._w_lck:
            #    self._sock.sendall(('UNSUB %s\r\n' % sid).encode())
            if sync:
                del self._sync[i]
                raise r.error
        if sync:
            if r.wait(_wait2) != True:
                r.error = MethodError('Method <%s> timeout' % name)
                #with self._w_lck:
                #    self._sock.sendall(('UNSUB %s\r\n' % sid).encode())
            del self._sync[i]
            if r.error:
                if isinstance(r.error, (str, unicode)):
                    raise RuntimeError(r.error)
                raise r.error
            return r.result
        else:
            return r

    def _run(self, defer):
        sock = socket.create_connection(self._address, 0.5)
        self._sock = sock
        defer(sock.close)

        def w(data):
            with self._w_lck:
                #log('%s[%s] %s' % (data[:3].decode(), id(sock), id(self._sock)), 'SEND')
                sock.sendall(data)

        bot_name = self._botname
        bot_id = 'bot.%s' % urn5(bot_name)

        w(('CONNECT {"name":"%s","verbose":false,"pedantic":false}\r\nSUB %s.* 2\r\n' % (bot_name, self.cli_id)).encode('utf8'))

        #r = sock.makefile('rb', 0)
        #defer(r.close)
        self._online.set()
        #print('_run', flush=True)
        #print(dir(sock))
        self._fg_serve_forever = True
        c = 0
        #cc = 0 
        while self._fg_serve_forever:
            #cc += 1
            cmd = ''
            data = ''
            try:
                data = recvline(sock)
                cmd, data = data[:3], data[3:]
                #log(cmd, '_RUN')
            except socket.timeout:
                #log('timeout', '_RUN')
                c += 1
                #log('%s) timeout' % c, 'socket0')
                if c > 2:
                    c = 0
                    #log('pong) timeout', 'socket0')
                    w(b'PONG\r\n')
                continue
            if not cmd:
                raise RuntimeError('[ Socket ] cmd is empty')
            if not data:
                raise RuntimeError('[ Socket ] data is empty')

            #if cc > 15:
            #    raise RuntimeError('[ DEBUG ] error for test')
            #log('>%s<' % data, '<%s>' % cmd)
            if 'MSG' == cmd:
                #MSG <subject> <sid> [reply-to] <#bytes>\r\n[payload]\r\n
                data = data.split()
                #print('data:', data)
                if 3 == len(data):
                    subj, sid, reply_id, size = data[0], data[1], '', int(data[2])
                else:
                    subj, sid, reply_id, size = data[0], data[1], data[2], int(data[3])
                payload = recvall(sock, size) if size > 0 else b''
                sock.recv(1)
                sock.recv(1)
                #print(cmd, subj, sid, reply_id, repr(payload)[:48], '...', len(payload))
                if sid[:2] == '1.':
                    sid = '2'
                if sid == '2':
                    fg_http = b'HTTP' == payload[:4]
                    if fg_http:
                        pass
                    else:
                        if b'\x1f\x8b\x08\x00' == payload[:4]:
                            if PY2:
                                payload = gzip_decode(payload)
                            else:
                                payload = gzip_decode(payload, -1)
                        if payload:
                            try:
                                payload = json.loads(payload, object_hook=_binary)
                            except Exception as e:
                                payload = {'error': str(e)}
                        else:
                            pyaload = {}
                    i = int(subj.rsplit('.', 1)[-1], 16)
                    _r = self._sync.get(i)
                    #log(_r, i)
                    if _r:
                        #print('[ASK]:', _r.ask)
                        #sys.stdout.flush()
                        if not reply_id and size == 0:
                            #print('1>', _r.is_set(), _r.ask)
                            #sys.stdout.flush()
                            _r.ask = True
                            _r.set()
                        else:
                            #print('2>', _r.is_set(), _r.ask)
                            #sys.stdout.flush()
                            while _r.is_set() and _r.ask:
                                time.sleep(0.001)
                            if fg_http:
                                headers, payload = payload.split(b'\r\n', 1)
                                status, headers = json.loads(headers[4:])
                                #if b'\x1f\x8b\x08\x00' == payload[:4]:
                                #    payload = gzip_decode(payload, -1)
                                _r.result = (status, headers, payload)
                                _r.error = None
                            else:
                                _r.result = payload.pop('result', None)
                                _r.error = payload.pop('error', None)
                            _r.set()
                    #else:
                    #    print(i, payload)
                else:
                    if b'\x1f\x8b\x08\x00' == payload[:4]:
                        if PY2:
                            payload = gzip_decode(payload)
                        else:
                            payload = gzip_decode(payload, -1)
                    if payload:
                        payload = json.loads(payload, object_hook=_binary)
                        #payload = pickle.loads(payload)
                    else:
                        payload = None
                    #print(subj)
                    i = int(sid.rsplit('.', 1)[-1], 16)
                    _r = self._sync.get(i)
                    #print('_r:', _r, i)
                    #print(', '.join(str(x) for x in self._sync.keys()))
                    if _r:
                        _r.put((subj, payload))
                    #else:
                    #    print(i, payload)
            elif 'PIN' == cmd:
                w(b'PONG\r\n')
            elif 'INF' == cmd:
                self._info = json.loads(data[2:])
                #print('INFO:', self._info)
                #cid = self._info['client_id']
            #elif cmd in ('PON', '+OK', '-ER'):
            #    pass

class AttrDict(dict):
    def __init__(self, *args, **kwargs):
        super(AttrDict, self).__init__(*args, **kwargs)
        self.__dict__ = self

def recvline(s):
    data = []
    while True:
        ch2 = s.recv(2)
        if ch2:
            data.append(ch2)
            if ch2[-1:] == b'\r':
                data.append(s.recv(1))
                break
            elif ch2[-1:] == b'\n':
                break
        else:
            break
    return b''.join(data).decode()

def recvall(r, n):
    data = []
    c = 0
    while c < n:
        packet = r.recv(n - c)
        if not packet:
            break
        c += len(packet)
        data.append(packet)
    return b''.join(data)

"""
def readall(r, n):
    data = []
    c = 0
    while c < n:
        #log(c, n)
        packet = r.read(n - c)
        if not packet:
            return b''
        c += len(packet)
        data.append(packet)
    return b''.join(data)
"""

def urn1(name):
    h1 = hashlib.sha1(uuid.NAMESPACE_DNS.bytes)
    h1.update(name.encode())
    return base64.b32encode(h1.digest()).decode('utf8')
    #return 'urn:sha1:%s' % base64.b32encode(h1.digest()).decode('utf8')

def urn5(name):
    h5 = hashlib.md5(uuid.NAMESPACE_DNS.bytes)
    h5.update(name.encode())
    return base64.b16encode(h5.digest()).decode('utf8').lower()
    #return 'urn:md5:%s' % base64.b16encode(h5.digest()).decode('utf8').lower()

_ts = "%Y-%m-%d %H:%M:%S"
__appname__ = 'bot'
__profile__ = 'test'
__index__   = os.getpid()
def log(msg, kind='info', begin='', end='\n'):
    global _ts, __hostname__, __appname__, __profile__, __version__, __index__
    try:
        try: ts = time.strftime(_ts)
        except: ts = time.strftime(_ts)
        if msg is None:
            data = ''.join(
                ('%s %s %s.%s %s %s:%s %s\n' % (ts, __hostname__, __appname__,__profile__,__version__,__index__,'traceback', msg)
                if i else '%s %s %s.%s %s %s:%s\n' % (ts, __hostname__, __appname__,__profile__,__version__,__index__,msg)
                ) for i, msg in enumerate(traceback.format_exc().splitlines())
            )
        else:
            data = '%s%s %s %s.%s %s %s:%s %s%s' % (begin,ts, __hostname__, __appname__,__profile__,__version__,__index__,kind, msg,end)
        sys.stdout.write(data)
        sys.stdout.flush()
    except:
        pass
        #traceback.print_exc()
try:
    if sys.log:
        log = sys.log
except:
    pass


