//[Skin Customization]
webix.skin.material.barHeight=32;webix.skin.material.tabbarHeight=32;webix.skin.material.rowHeight=26;webix.skin.material.listItemHeight=26;webix.skin.material.inputHeight=26;webix.skin.material.layoutMargin.wide=8;webix.skin.material.layoutMargin.space=8;webix.skin.material.layoutPadding.space=8;
 webix.skin.set('material');