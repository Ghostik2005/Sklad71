//[Skin Customization]
webix.skin.material.barHeight=40;webix.skin.material.tabbarHeight=40;webix.skin.material.rowHeight=28;webix.skin.material.listItemHeight=28;webix.skin.material.inputHeight=30;webix.skin.material.layoutMargin.wide=10;webix.skin.material.layoutMargin.space=10;webix.skin.material.layoutPadding.space=10;
 webix.skin.set('material');