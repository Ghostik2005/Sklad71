# coding: utf-8
#from gevent import monkey
#monkey.patch_all()

import sys, os, time, random

import multiprocessing
from multiprocessing import freeze_support
from multiprocessing.managers import SyncManager, BaseProxy, \
    NamespaceProxy, EventProxy, AcquirerProxy, ConditionProxy, BarrierProxy, PoolProxy, ListProxy, DictProxy

from multiprocessing import process
import threading

import __main__sync_helper as helper

#process.current_process().authkey = b'masterkey'
#print(process.current_process().authkey)

class MsEvent(threading.Event):
    def __init__(self, **kwds):
        self.__d__= {}
        super().__init__()
        self.__d__.update(kwds)
        self.__getitem__ = self.__d__.__getitem__
        self.__setattr__ = self.__setitem__ = self.__d__.__setitem__
        self.__delattr__ = self.__delitem__ = self.__d__.__delitem__
        self.__len__ = self.__d__.__len__
        self.__getattribute = self.__getattribute__
        self.__getattribute__ = self._getattribute

    """
    def __repr__(self):
        items = list(self.__dict__.items())
        temp = []
        for name, value in items:
            if not name.startswith('_'):
                temp.append('%s=%r' % (name, value))
        temp.sort()
        return '%s(%s)' % (self.__class__.__name__, ', '.join(temp))
    """
    def _getattribute(self, key):
        if key == '__d__':
            return self.__d__
        elif key in self.__d__:
            return self.__d__[key]
        return self.__getattribute(key)

    def keys(self):
        return list(self.__d__.keys())

    def set(self, **kwds):
        self.__d__.update(kwds)
        return super().set()

    def clear(self):
        self.__d__.clear()
        return super().clear()

    def get(self, timeout=None):
        if self.wait(timeout=timeout):
            return self.__d__


class MsEventProxy(BaseProxy):
    _exposed_ = ('keys','__getitem__','__setitem__','__delitem__','__len__','get', 'is_set','set','clear','wait','get', '__getattribute__','__setattr__','__delattr__')
    def keys(self):
        return self._callmethod('keys')
    def __getitem__(self, k):
        return self._callmethod('__getitem__', (k,))
    def __setitem__(self, k, v):
        return self._callmethod('__setitem__', (k, v))
    def __delitem__(self, k):
        return self._callmethod('__delitem__', (k,))
    def __len__(self):
        return self._callmethod('__len__')
    def is_set(self):
        return self._callmethod('is_set')
    def set(self, **kwds):
        return self._callmethod('set', (), kwds)
    def clear(self):
        return self._callmethod('clear')
    def wait(self, timeout=None):
        return self._callmethod('wait', (timeout,))
    def get(self, timeout=None):
        return self._callmethod('get', (timeout,))
    def __getattr__(self, key):
        if key[0] == '_':
            return object.__getattribute__(self, key)
        callmethod = object.__getattribute__(self, '_callmethod')
        return callmethod('__getattribute__', (key,))
    def __setattr__(self, key, value):
        if key[0] == '_':
            return object.__setattr__(self, key, value)
        callmethod = object.__getattribute__(self, '_callmethod')
        return callmethod('__setattr__', (key, value))
    def __delattr__(self, key):
        if key[0] == '_':
            return object.__delattr__(self, key)
        callmethod = object.__getattribute__(self, '_callmethod')



class MsManager(SyncManager):
    pass
MsManager.register('MsEvent', MsEvent, MsEventProxy)
MsManager.register('get_namespace', proxytype=NamespaceProxy)  # , exposed=namespaceExposed)
MsManager.register('get_queue')
MsManager.register('get_event', proxytype=MsEventProxy)
MsManager.register('get_lock', proxytype=AcquirerProxy)
MsManager.register('get_rlock', proxytype=AcquirerProxy)
MsManager.register('get_semaphore', proxytype=AcquirerProxy)
MsManager.register('get_bounded_semaphore', proxytype=AcquirerProxy)
MsManager.register('get_condition', proxytype=ConditionProxy)
#MsManager.register('get_barrier', proxytype=BarrierProxy)
MsManager.register('get_pool', proxytype=PoolProxy)
MsManager.register('get_list', proxytype=ListProxy)
MsManager.register('get_dict', proxytype=DictProxy)
MsManager.register('save')
MsManager.register('get_module')

# register the Foo class; make `f()` and `g()` accessible via proxy
#MyManager.register('Foo1')

# register the Foo class; make `g()` and `_h()` accessible via proxy
#MyManager.register('Foo2')

# register the generator function baz; use `GeneratorProxy` to make proxies
class GeneratorProxy(BaseProxy):
    _exposed_ = ['__next__']
    def __iter__(self):
        return self
    def __next__(self):
        return self._callmethod('__next__')
#MyManager.register('baz', proxytype=GeneratorProxy)

# register get_operator_module(); make public functions accessible via proxy
#MyManager.register('operator')


BaseProxy._callmethod2 = BaseProxy._callmethod
def _callmethod(self, methodname, args=(), kwds={}):
    r = None
    try:
        r = self._callmethod2(methodname, args=args, kwds=kwds)
    except (EOFError, BrokenPipeError, ConnectionResetError) as e:
        print('try21', flush=True)
        self._connect()
        r = self._callmethod2(methodname, args=args, kwds=kwds)
    return r
BaseProxy._callmethod = _callmethod

try:
    log = sys.log
except:
    log = lambda msg, kind='info', begin='', end='\n': print('%s %s %s%s' % (begin, kind, msg,end), flush=True)

manager = None
def get_manager(addr, authkey=None):
    global manager
    if manager:
        return manager
    if not authkey:
        authkey = b'noname.default:masterkey'
    process.current_process().authkey = authkey
    addr = helper.MsList(addr)
    #print(addr)
    #print(type(addr))
    #return
    manager = MsManager(addr, serializer='ms71')
    #print(dir(manager))
    old_err = ''
    while True:
        try:
            manager.connect()
            break
        except Exception as e:
            new_err = str(e)
            if old_err != new_err:
                old_err = new_err
                log(old_err, kind='manager')
        time.sleep(1 + random.random())
    return manager

## A very generous timeout when it comes to local connections...
#CONNECTION_TIMEOUT = 20.
#...
#def _init_timeout(timeout=CONNECTION_TIMEOUT):
#        return time.time() + timeout
sys.modules['multiprocessing'].__dict__['managers'].__dict__['connection']._init_timeout = lambda *a, **kw: time.time() + 10
rmanager = None
def get_rmanager(addr, authkey=None):
    global rmanager
    if rmanager:
        return rmanager
    if not authkey:
        authkey = b'noname.default:masterkey'
    process.current_process().authkey = authkey
    addr = helper.MsList(addr)
    #print(addr)
    #print(type(addr))
    #return
    rmanager = MsManager(addr, serializer='ms71')
    #print(rmanager, flush=True)
    old_err = ''
    while True:
        try:
            rmanager.connect()
            break
        except Exception as e:
            new_err = str(e)
            if old_err != new_err:
                old_err = new_err
                log(old_err, kind='rmanager')
        try:
            time.sleep(1 + random.random())
        except:
            os._exit(2)
    return rmanager


def test2(q):
    while True:
        try:
            item = q.get()
        except Exception as e:
            print('q.get1', str(e))
            time.sleep(1)
            continue
        try: q.task_done()
        except: pass
        print('q.get2:', item)

def recv_forever(m, q=None):
    while True:
        try:
            if q is None:
               q = m.get_queue()
            print(q.get(), flush=True)
        except (EOFError, ConnectionRefusedError, multiprocessing.context.AuthenticationError) as e:
            print(str(e), flush=True)
            time.sleep(1 + random.random())
            continue
        except multiprocessing.managers.RemoteError as e:
            print(str(e), flush=True)
            del q
            q = None
            time.sleep(1 + random.random())
            continue

def send_forever(m, q=None):
    pid = os.getpid()
    while True:
        try:
            if q is None:
               q = m.get_queue()
            q.put('[%s] %s' % (pid, ('%i' % time.time())[-4:]))
        except (EOFError, ConnectionRefusedError, multiprocessing.context.AuthenticationError) as e:
            print(str(e), flush=True)
            time.sleep(1 + random.random())
            continue
        except multiprocessing.managers.RemoteError as e:
            print(str(e), flush=True)
            del q
            q = None
            continue
        time.sleep(1 + random.random())

def test():
    process.current_process().authkey = b'sklad.antey:masterkey'

    addr = helper.MsList(('127.0.0.1', 50002))  # nats01
    #addr = helper.MsList(('92.53.91.157', 80))  # nats01
    #addr = helper.MsList(('95.213.200.242', 80))  # nats02
    #addr = helper.MsList(('80.93.177.141', 80))  # nats03
    print(addr)

    print(type(addr))
    #return
    manager = MsManager(addr, serializer='ms71')
    #manager = MsManager(('127.0.0.1', 50002), serializer='ms71')
    #manager = MsManager(('127.0.0.1', 50002), serializer='xmlrpclib')
    print(dir(manager))
    old_err = ''
    while True:
        try:
            manager.connect()
            break
        except Exception as e:
            new_err = str(e)
            if old_err != new_err:
                old_err = new_err
            print(old_err, flush=True)
            time.sleep(1 + random.random())
    #return
    """
    print('-' * 20)

    f1 = manager.Foo1()
    f1.f()
    f1.g()
    assert not hasattr(f1, '_h')
    assert sorted(f1._exposed_) == sorted(['f', 'g'])

    print('-' * 20)

    f2 = manager.Foo2()
    f2.g()
    f2._h()
    assert not hasattr(f2, 'f')
    assert sorted(f2._exposed_) == sorted(['g', '_h'])

    print('-' * 20)

    #it = manager.baz()
    #for i in it:
    #    print('<%d>' % i, end=' ')
    #print()

    print('-' * 20)

    op = manager.operator()
    print('op.add(23, 45) =', op.add(23, 45))
    #print('op.pow(2, 94) =', op.pow(2, 94))
    #print('op._exposed_ =', op._exposed_)
    #ns = manager.get_global()
    #print(ns)
    """
    return manager

##

if __name__ == '__main__':
    freeze_support()
    m = test()
    e = m.get_event()
    q = m.get_queue()
    kv = m.get_dict('', True)
    d = m.get_dict()
    d[1] = 2
    d[3] = 4
    d[5] = 6
    d[7] = 8
    d[9] = 0
    print('m, e, q, kv, d')
    #s = m.get_semaphore()
    #bs = m.get_bounded_semaphore()
    #c = m.get_condition()
    #b = m.get_barrier()
