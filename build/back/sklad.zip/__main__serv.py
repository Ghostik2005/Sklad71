# coding: utf-8

__appname__ = 'noname'
__version__ = '00.000.0000'
__profile__ = 'default'
__index__   = 0


import sys
if __name__ == '__main__':
    # env PYTHONIOENCODING="UTF-8"
    if sys.stdout.encoding != 'UTF-8':
        sys.stdout = open(sys.stdout.fileno(), mode='w', buffering=1, encoding='UTF-8')
    if sys.stderr.encoding != 'UTF-8':
        sys.stderr = open(sys.stderr.fileno(), mode='w', buffering=1, encoding='UTF-8')

cherrypy = None
setproctitle = None
#try:
#    import setproctitle
#except:
#    log('setproctitle not imported', 'import')
#    #from pip._internal import main as _pip_main
#    #rc = _pip_main(['install', 'setproctitle', '-U'])
#    #try:
#    #    import setproctitle
#    #except:
#    #    pass

try:
    import socket
    __hostname__ = socket.gethostname().lower()
except:
    __hostname__ = 'noname'
try:
    sys.conf
except:
    sys.conf = {
        'profile': __profile__,
        'workers': 1,
        'port': 0,
    }

import os, time, traceback, threading
from pprint import pprint

try:
    import ssl
    ssl._create_default_https_context = ssl._create_unverified_context
except:
    pass

import struct, copy
import multiprocessing as mp
from multiprocessing import dummy as tp
import urllib.parse


def main(fg_reload=False):
    global __appname__, __version__, __profile__, __index__, cherrypy, setproctitle
    __index__ = os.getpid()
    p1 = os.path.dirname(os.path.abspath(__file__))
    p2 = os.path.abspath(sys.path[0])
    if p2 != p1 and p2[-4:] != '.zip' and  p1[-4:] != '.zip':
        sys.path[0] = p1
    if 'darwin' == sys.platform:
        os.environ.putenv('OBJC_DISABLE_INITIALIZE_FORK_SAFETY', 'YES')

    repo_dir = os.path.dirname(os.path.abspath(__file__))
    if os.path.isfile(repo_dir):
        curname = repo_dir
        repo_dir = os.path.dirname(repo_dir)
    else:
        curname = None
    sys.repo_dir = repo_dir
    sys.curname = curname

    try:
        import cherrypy
    except:
        #from pip._internal import main as _pip_main
        #rc = _pip_main(['install', 'cherrypy', '-U'])
        #import cherrypy
        log('cherrypy not imported', 'import')
        sys.exit(0)
    _cherrypy_init()

    # todo: ???
    #for nm in ('file_conf',):
    #    if not sys.conf.get('file_conf'):
    #        log('%s not defined or empty' %nm, 'config')
    #        sys.exit(0)


    cherrypy.config.update({'environment': 'production',
        #
    })

    __profile__ = str(sys.conf.get('profile', ''))
    if not __profile__:
        __profile__ = 'default'
    sys.conf['profile'] = __profile__
    from importlib import reload
    import __main__init
    if fg_reload:
        reload(__main__init)
    try:
        import __main__init as __init
        __appname__ = __init.__appname__
        __version__ = __init.__version__
        __init.__profile__ = __profile__
    except:
        pass

    try:
        import setproctitle
    except:
        log('setproctitle not imported', 'import')
    if setproctitle:
        setproctitle.setproctitle('python: master %s.%s' % (__appname__, __profile__))

    workers = int(sys.conf.get('workers', 1))
    if not workers:
        workers = 1
    sys.conf['workers'] = workers
    sys.conf['worker_id'] = 0
    pool = []
    try:
        def NewManager(key=None, token='masterkey'):
            if key is None:
                key = '%s.%s' % (__appname__, __profile__)
            try:
                conf_rmanager = sys.conf.pop('rmanager')
            except:
                conf_rmanager = None
            if conf_rmanager:
                if isinstance(conf_rmanager, (tuple, list)):
                    address, token = conf_rmanager
                else:
                    address = conf_rmanager.pop('address')
                    token = conf_rmanager.pop('token')
                if isinstance(address, str):
                    address = address.split(':')
                elif isinstance(address, bytes):
                    address = address.decode().split(':')
                address = (address[0], int(address[1]))
                if isinstance(token, str):
                    token = token.encode()
                authkey = b'%s:%s' % (key.encode(), token)
                sys.conf['rmanager'] = {'address': address, 'authkey': authkey}
            else:
                if isinstance(token, str):
                    token = token.encode()
                authkey = b'%s:%s' % (key.encode(), token)
            import __main__sync_serv
            if fg_reload:
                reload(__main__sync_serv)
            #if hasattr(sys, 'manager') and sys.manager:
            #    manager = sys.manager
            #    __main__sync_serv.manager = manager
            #else:
            manager = __main__sync_serv.get_manager(authkey)
            return manager

        manager = None
        try:
            from __main__init import init_manager
        except:
            init_manager = None
        if init_manager:
            manager = init_manager(NewManager)
        else:
            manager = NewManager()
        #print('attr:', hasattr(sys, 'manager'), flush=True)
        if hasattr(sys, 'manager') and sys.manager == manager:
            pass
            #print(manager)
            #print(sys.manager)
            #print(sys.manager_server)
            #print(flush=True)
        else:
            sys.manager, sys.manager_server = manager, None
        if manager and sys.manager_server is None:
            sys.manager_server = manager.get_server()
            _t = tp.Process(target=sys.manager_server.serve_forever)
            _t.daemon = True
            _t.start()
            time.sleep(0)
        if sys.manager_server.address:
            sys.conf['manager'] = {'address': sys.manager_server.address, 'authkey': sys.manager_server.authkey.decode().encode()}

        init_master = None
        try:
            from __main__init import init_master
        except:
            init_master = None
        if sys.manager_server:
            log('manager %s:%s running' % sys.manager_server.address, kind='master')
        if init_master:
            if not sys.manager_server:
                log('running', kind='master')
            time.sleep(0)
            init_master()

        workers = sys.conf.get('workers', workers)
        for i in range(workers):
            conf = copy.deepcopy(sys.conf)
            conf['worker_id'] = i+1
            p = mp.Process(target=_main, args=(conf,))
            p.daemon = True
            pool.append(p)
            p.start()
            time.sleep(0)

        c = 1
        while c:
            a1, a2 = 0, 0
            t1 = time.time()
            t2 = int(t1) + 1
            #time.sleep(1)
            c = 0
            for i, p in enumerate(pool or []):
                if p.is_alive():
                    c += 1
                    a1 += 1
                else:
                    a2 += 1
                    if 1 == p.exitcode:
                        #print('sys.curname:', sys.curname, flush=True)
                        sys.FG_RELOAD = sys.curname
                        raise KeyboardInterrupt
                    #print('%02d)' % i, p, p.is_alive(), p.exitcode, flush=True)
                time.sleep(0)
            if not workers:
                c += 1
            if c:
                t = t2 - time.time()
                if a2 > 0:
                    #log('loop %.4f, (%s, %s)' % (t, a1, a2), kind='master')
                    pass
                if t > 0:
                    time.sleep(t)
    except KeyboardInterrupt:
        #print('\r\n', end='', flush=True)
        pass
    finally:
        try:
            print('\r', end='', flush=True)
        except:
            pass
        try:
            time.sleep(0.1)
        except:
            pass
        for p in pool:
            p.terminate()
            p.join()
        log('shutdown', kind='master', begin='\r')

def _main(conf):
    global __hostname__, __appname__, __version__, __profile__, __index__, cherrypy, setproctitle
    __index__ = os.getpid()

    repo_dir = os.path.dirname(os.path.abspath(__file__))
    if os.path.isfile(repo_dir):
        curname = repo_dir
        repo_dir = os.path.dirname(repo_dir)
    else:
        curname = None
    sys.repo_dir = repo_dir
    sys.curname = curname

    sys.conf = conf
    import __main__init as __init
    __profile__ = sys.conf['profile']
    __appname__ = __init.__appname__
    __version__ = __init.__version__
    __init.__profile__ = __profile__
    try:
        import setproctitle
    except:
        log('setproctitle not imported', 'import')
    if setproctitle:
        setproctitle.setproctitle('python: worker %s.%s' % (__appname__, __profile__))

    from __main__sync_cli import get_manager, get_rmanager
    #print(sys.conf, flush=True)
    if 'manager' in sys.conf:
        sys.manager = get_manager(sys.conf['manager']['address'], sys.conf['manager']['authkey'])
    else:
        sys.manager = None
    if 'rmanager' in sys.conf:
        sys.rmanager = get_rmanager(sys.conf['rmanager']['address'], sys.conf['rmanager']['authkey'])
    else:
        sys.rmanager = None

    workers = sys.conf.get('workers')
    if workers:
        workers = int(workers)
    else:
        workers = 1
    sys.conf['workers'] = workers
    port = sys.conf.get('port')
    if port:
        port = int(port)
    else:
        port = 0
    if port > 0:
        port = port + conf['worker_id'] - 1
    sys.conf['port'] = port

    import cherrypy
    _cherrypy_init()
    #cherrypy.config.update({'environment': 'production',
    #    #'server.socket_host': '64.72.221.48',
    #    #'server.socket_port': 80,
    #})
    #cherrypy.config.update({
    #    'log.screen': True,
    #    'engine.autoreload.on': False,
    #})
    try:
        from __main__init import init_handler
    except:
        init_handler = None
    if init_handler:
        handler = init_handler(MS71WSGIJSONRPCRequestHandler)
    else:
        handler = None
    if handler:
        if isinstance(handler, MS71WSGIJSONRPCRequestHandler):
            cherrypy.tree.graft(handler.handle_request, '/')
        else:
            cherrypy.tree.graft(handler, '/')
    else:
        return

    #cherrypy.server.unsubscribe()
    server = cherrypy.server
    #server = cherrypy._cpserver.Server()
    server.accepted_queue_size = 100
    server.accepted_queue_timeout = 25
    server.socket_host = '127.0.0.1'
    server.socket_port = port
    server.socket_queue_size = 100
    server.socket_timeout = 25
    server.thread_pool = 3
    #server.subscribe()

    cherrypy.engine.start()
    port = server.bound_addr[1]
    key = '%s.%s' % (__appname__, __profile__)
    log('%s:%s running' % server.bound_addr, kind='worker')

    #print(sys.conf, flush=True)
    #print('server2.accepted_queue_size:', server2.accepted_queue_size)
    #print('server2.accepted_queue_timeout:', server2.accepted_queue_timeout)
    #print('server2.base:', server2.base)
    #print('server2.description:', server2.description)
    #print('server2.socket_port:', server2.socket_port)
    #print('server2.httpserver :', server2.httpserver)
    ##print('server2.bound_addr :', server2.bound_addr)
    #print('server2.instance   :', server2.instance)
    #print('server2.socket_queue_size:', server2.socket_queue_size)
    #print('server2.socket_timeout:', server2.socket_timeout)
    #print('server2.thread_pool:', server2.thread_pool)
    #print('server2.thread_pool_max:', server2.thread_pool_max)

    #cherrypy.engine.block()
    event_close = tp.Event()
    subscribe2(('127.0.0.1', 9080), key, port, event_close)
    log('%s:%s shutdown' % server.bound_addr, kind='worker', begin='\r')
    sys.exit(0)


"""
_fg_ms71lib_path_insert = False
try:
    import ms71lib
except:
    _pi = '/ms71/repo/msclib.zip'
    if 'posix' == os.name:
        _fg_ms71lib_path_insert = True
        sys.path.insert(0, _pi)
    else:
        for d in ('c:', 'd:'):
            fn = d + _pi
            if os.path.isfile(fn):
                _fg_ms71lib_path_insert = True
                sys.path.insert(0, fn)
                break
    import ms71lib
"""

from ms71lib.server import SimpleJSONRPCDispatcher, gzip_encode, gzip_decode
from ms71lib.client import dumps, Fault
#if _fg_ms71lib_path_insert:
#    del sys.path[0]
#from pprint import pprint
from types import GeneratorType
class MS71WSGIJSONRPCRequestHandler(SimpleJSONRPCDispatcher):

    def __init__(self, allow_none=True, encoding=None):
        SimpleJSONRPCDispatcher.__init__(self, allow_none, encoding)

    def handle_request(self, environ, start_response, request_text=None):
        response = None

        #for k in environ:
        #    log('%s: %s' % (k, environ[k]), kind='env')
        _pi = environ.get('PATH_INFO', '')
        pq = environ.get('REQUEST_URI', '')
        if pq:
            pq = pq.split('?', 1)
        else:
            pq = [_pi, environ.get('QUERY_STRING', '')]
        uri = pq[0]
        if request_text is None and environ.get('REQUEST_METHOD', None) == 'GET':
            if '/favicon.ico' == _pi:
                start_response('404 Not Found', [])
                return b''
            if uri and uri[-1] == '/':
                method = uri[:-1].split('/')[-1]
            else:
                method = uri.split('/')[-1]
            params = []
            kwargs = {}
            if len(pq) > 1:
                for kv in pq.pop(1).split('&'):
                    kv = kv.split('=', 1)
                    _k = urllib.parse.unquote(kv[0]).strip()
                    if len(kv) > 1:
                        kwargs[_k] = urllib.parse.unquote(kv[1]).strip()
                    else:
                        params.append(_k)
            length = -1
            #print('<%s>' % method, params, kwargs, flush=True)
            if not method:
                    response = '%s %s %s.%s %s %s:%s/%s' % (time.strftime(_ts), __hostname__, __appname__,__profile__, __version__, __index__,sys.conf['worker_id'],sys.conf['workers'])
                    response = response.encode('utf-8')
                    length = len(response)
                    start_response("200 OK", [
                        ("Content-Type", "text/plain; charset=utf-8"),
                        ("Cache-Control", "no-cache"),
                        ("Access-Control-Allow-Origin", "*"),
                        ("Content-Length", str(length)),
                    ])
                    log('%s "%s" %s %s' % (environ.get('REQUEST_METHOD', 'GET'), environ.get('PATH_INFO', ''), 200, length), kind='http')
                    return [response,]

            #request_text = dumps(params, kwargs, method, methodresponse=None, encoding=None, allow_none=1)
            try:
                response = self._dispatch(method, params, kwargs)
                _type_response = type(response)
                if _type_response == GeneratorType:
                    start_response("200 OK", [
                        ("Content-Type", "text/event-stream; charset=utf-8"),
                        ("Cache-Control", "no-cache"),
                        ("Access-Control-Allow-Origin", "*"),
                    ])
                    log('%s "%s" %s %s' % (environ.get('REQUEST_METHOD', 'GET'), environ.get('PATH_INFO', ''), 200, length), kind='http')
                    return response
                # wrap response in a singleton tuple
                response = (response,)
                response = dumps(response, methodresponse=1,
                             allow_none=self.allow_none, encoding=self.encoding)
            except Fault as fault:
                response = dumps(fault, allow_none=self.allow_none,
                                 encoding=self.encoding)
            except:
                # report exception back to server
                exc_type, exc_value, exc_tb = sys.exc_info()
                if hasattr(self, '_send_traceback_header') and self._send_traceback_header:
                    exc_value = str(exc_value) + '\n' + traceback.format_exc()
                    print(exc_value, flush=True)
                response = dumps(
                    Fault(1, "%s:%s" % (exc_type, exc_value)),
                    encoding=self.encoding, allow_none=self.allow_none,
                    )
        else:
            try:
                length = int(environ.get("CONTENT_LENGTH", None))
            except (TypeError, ValueError):
                length = -1
            if request_text is None:
                request_text = environ["wsgi.input"].read(length)
                if "gzip" == environ.get("HTTP_CONTENT_ENCODING", environ.get("CONTENT_ENCODING")):
                    request_text = gzip_decode(request_text)
        #print(1111, flush=True)]
        # print('*'*10, uri, sep='\t', flush=True)
        if response is None:
            response = self._marshaled_dispatch(request_text, path=uri)
        length = len(response)
        if length > 1400:
            response = gzip_encode(response)
            length = len(response)
            start_response("200 OK", [
                ("Content-Type", "application/json; charset=utf-8"),
                ("Cache-Control", "no-cache"),
                ("Access-Control-Allow-Origin", "*"),
                ("Content-Encoding", "gzip"),
                ("Content-Length", str(length)),
            ])
        else:
            start_response("200 OK", [
                ("Content-Type", "application/json; charset=utf-8"),
                ("Cache-Control", "no-cache"),
                ("Access-Control-Allow-Origin", "*"),
                ("Content-Length", str(length)),
            ])
        log('%s "%s" %s %s' % (environ.get('REQUEST_METHOD', 'GET'), _pi, 200, length), kind='http')
        # print('*'*10, response, sep='\t', flush=True)
        return (response,)


def subscribe2(addr, key, port, event_close):
    _key = key.encode('utf8')
    _port = ('127.0.0.1:%s' % port).encode('utf8')
    data = struct.pack('<BHB', 224, 76 + len(_key) + len(_port), 0) + \
    b'\x03\x00key' + struct.pack('<H', len(_key)) + _key + \
    b'\x07\x00address' + struct.pack('<H', len(_port)) + _port + \
    b'\t\x00modifier1\x01\x000\t\x00modifier2\x01\x000\x05\x00cores\x01\x001\x04\x00load\x01\x000\x06\x00weight\x01\x000'
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(1)
    while not event_close.is_set():
        #log(key, 'key')
        _subscribe2(sock, addr, data)
        if event_close.is_set():
            break
        try:
            event_close.wait(timeout=8)
        except:
            break
    _subscribe2(sock, addr, data, 1)
    sock.close()

def _subscribe2(sock, addr, data, closed=0):
    if closed:
        data = data[:3] + b'\x01' + data[4:]
    sock.sendto(data, addr)


_ts = "%Y-%m-%d %H:%M:%S"
def log(msg, kind='info', begin='', end='\n'):
    global _ts, __hostname__, __appname__, __profile__, __version__, __index__
    try:
        try: ts = time.strftime(_ts)
        except: ts = time.strftime(_ts)
        if msg is None:
            data = ''.join(
                ('%s %s %s.%s %s %s:%s %s\n' % (ts, __hostname__, __appname__,__profile__,__version__,__index__,'traceback', msg)
                if i else '%s %s %s.%s %s %s:%s\n' % (ts, __hostname__, __appname__,__profile__,__version__,__index__,msg)
                ) for i, msg in enumerate(traceback.format_exc().splitlines())
            )
        else:
            data = '%s%s %s %s.%s %s %s:%s %s%s' % (begin,ts, __hostname__, __appname__,__profile__,__version__,__index__,kind, msg,end)
        sys.stdout.write(data)
        sys.stdout.flush()
    except:
        pass
        #traceback.print_exc()

sys.log = log

def _cherrypy_init():
    global log, cherrypy
    for f in tuple(cherrypy.engine.listeners.get('log') or []):
        cherrypy.engine.unsubscribe('log', f)
    #@cherrypy.engine.subscribe('log')
    #def _buslog(msg, level):
    #    log(msg, kind='ENGINE')
    #cherrypy._buslog = cherrypy.engine.subscribe('log')(_buslog)


if '__main__' == __name__:
    #mp.freeze_support()
    #mp.set_start_method('spawn')
    main()
