# coding: utf-8
__version__ = '00.000.0001'
#-- do not edite
def version():
    global __version__
    return __version__
#-- do not edite --

import sys
from . import sklad

