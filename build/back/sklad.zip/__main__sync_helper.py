# coding: utf-8

import sys, os, time, random

import multiprocessing, socket
#from multiprocessing import freeze_support
#from multiprocessing.managers import SyncManager, BaseProxy, NamespaceProxy, DictProxy
from multiprocessing import process, AuthenticationError
from multiprocessing.managers import BaseManager, listener_client, BaseProxy, MakeProxyType, DictProxy
from multiprocessing.connection import Listener, Client, Connection, ConnectionWrapper

import io, copyreg, pickle
try:
    import gzip
except ImportError:
    gzip = None  # python can be built without zlib/gzip support

def gzip_encode(data):
    """data -> gzip encoded data

    Encode data using the gzip content encoding as described in RFC 1952
    """
    if not gzip:
        raise NotImplementedError
    f = io.BytesIO()
    with gzip.GzipFile(mode="wb", fileobj=f, compresslevel=1) as gzf:
        if data.__class__.__name__ in ("generator", "list", "tuple"):
            for row in data:
                gzf.write(row)
        elif hasattr(data, "read"):
            part = data.read(4096)
            while part:
                gzf.write(part)
                part = data.read(4096)
        else:
            gzf.write(data)
        #gzf.close()
    encoded = f.getvalue()
    f.close()
    return encoded

def gzip_decode(data, max_decode=-1):
    """gzip encoded data -> unencoded data

    Decode data using the gzip content encoding as described in RFC 1952
    """
    if not gzip:
        raise NotImplementedError
    with gzip.GzipFile(mode="rb", fileobj=io.BytesIO(data)) as gzf:
        try:
            if max_decode < 0: # no limit
                decoded = gzf.read()
            else:
                decoded = gzf.read(max_decode + 1)
        except OSError:
            raise ValueError("invalid data")
    if max_decode >= 0 and len(decoded) > max_decode:
        raise ValueError("max gzipped payload length exceeded")
    return decoded

class MsList(list):

    def __hash__(self):
        return id(self)

def address_type(address):
    '''
    Return the types of the address

    This can be 'AF_INET', 'AF_UNIX', or 'AF_PIPE'
    '''
    if type(address) in (tuple, MsList):
        return 'AF_INET'
    elif type(address) is str and address.startswith('\\\\'):
        return 'AF_PIPE'
    elif type(address) is str:
        return 'AF_UNIX'
    else:
        raise ValueError('address type of %r unrecognized' % address)
multiprocessing.connection.address_type = address_type

def SocketClient(address):
    '''
    Return a connection object connected to the socket given by `address`
    '''
    family = address_type(address)
    with socket.socket( getattr(socket, family), ) as s:
        s.setblocking(True)
        try:
            s.connect(tuple(address) if type(address) == MsList else address)
        except Exception as e:
            print('s.connect:', str(e), flush=True)
            raise e
        return Connection(s.detach())
multiprocessing.connection.SocketClient = SocketClient

class Ms71ForkingPickler(pickle.Pickler):
    '''Pickler subclass used by multiprocessing.'''
    _extra_reducers = {}
    _copyreg_dispatch_table = copyreg.dispatch_table

    def __init__(self, *args):
        super().__init__(*args)
        self.dispatch_table = self._copyreg_dispatch_table.copy()
        self.dispatch_table.update(self._extra_reducers)

    @classmethod
    def register(cls, type, reduce):
        '''Register a reduce function for a type.'''
        cls._extra_reducers[type] = reduce

    @classmethod
    def dumps(cls, obj, protocol=None):
        buf = io.BytesIO()
        cls(buf, protocol).dump(obj)
        return buf.getbuffer()

    loads = pickle.loads

def _ms71_dumps(obj):
    s = Ms71ForkingPickler.dumps(obj)  # , 2)
    if len(s) > 512:
        #print('dump1:', len(s), flush=True)
        s = gzip_encode(s)
        #print('dump2:', len(s), flush=True)
    else:
        #print('dumps:', len(s), flush=True)
        pass
    return s
    #return Ms71ForkingPickler.dumps(obj, 2)

def _ms71_loads(s):
    if b'\x1f\x8b\x08\x00' == s[:4]:
        #print('load1:', len(s), flush=True)
        s = gzip_decode(s)
        #print('load2:', len(s), flush=True)
    else:
        #print('loads:', len(s), flush=True)
        pass
    return Ms71ForkingPickler.loads(s)

class Ms71Listener(Listener):
    def accept(self):
        obj = Listener.accept(self)
        return ConnectionWrapper(obj, _ms71_dumps, _ms71_loads)

def Ms71Client(*args, **kwds):
    return ConnectionWrapper(Client(*args, **kwds), _ms71_dumps, _ms71_loads)

listener_client['ms71'] = (Ms71Listener, Ms71Client)

MESSAGE_LENGTH = 20

CHALLENGE = b'#CHALLENGE#'
WELCOME = b'#WELCOME#'
FAILURE = b'#FAILURE#'

import hmac, base64
def deliver_challenge(connection, authkey):
    assert isinstance(authkey, bytes)
    _conn = connection._conn if isinstance(connection, ConnectionWrapper) else connection
    if not hasattr(_conn, 'ok'):
        _conn.ok = False
    #print('deliver_challenge:[%s]' % _conn.ok, type(connection), authkey, flush=True)
    if _conn.ok:
        return
    data = _conn._read(_conn._handle, 256)
    #print('deliver:', data, flush=True)
    _init1 = data.split()

    appid, apikey =  authkey.split(b':')
    if not apikey:
        digest = _init1[-1]
    elif len(apikey) == 32:
        digest = apikey
    else:
        digest = base64.b64encode(hmac.new(apikey, appid, 'md5').digest())
    #print('_init1:', _init1, flush=True)
    #_init1 = _conn._read(_conn._handle, 256).split()
    if digest != _init1[-1]:
        _init2 = b"""HTTP/1.1 403 Forbidden\r\n\r\n"""
    else:
        _init2 = b"""HTTP/1.1 101 Switching Protocols\r\nUpgrade: sync\r\nConnection: Upgrade\r\n\r\n"""
    #print('deliver:', _init2, flush=True)
    _conn._send(_init2)
    if digest != _init1[-1]:
        raise AuthenticationError('Digest received was wrong2')
    _conn.ok = True
    #print('Handshake2', flush=True)
    return

    message = os.urandom(MESSAGE_LENGTH)
    connection.send_bytes(CHALLENGE + message)
    digest = hmac.new(authkey, message, 'md5').digest()
    response = connection.recv_bytes(256)        # reject large message
    if response == digest:
        connection.send_bytes(WELCOME)
    else:
        connection.send_bytes(FAILURE)
        raise AuthenticationError('digest received was wrong')

def answer_challenge(connection, authkey):
    assert isinstance(authkey, bytes)
    _conn = connection._conn if isinstance(connection, ConnectionWrapper) else connection
    if not hasattr(_conn, 'ok'):
        _conn.ok = False
    #print('answer_challenge[%s]:' % _conn.ok, type(connection), authkey, flush=True)
    if _conn.ok:
        return

    appid, apikey =  authkey.split(b':')
    if len(apikey) == 32:
        _init1 = b"""GET /%s HTTP/1.1\r\nHost: sync.local\r\nUpgrade: sync\r\nConnection: Upgrade\r\nX-API-Key: %s\r\n\r\n""" % (appid, apikey)
    else:
        _init1 = b"""GET /%s HTTP/1.1\r\nHost: sync.local\r\nUpgrade: sync\r\nConnection: Upgrade\r\nX-API-Key: %s\r\n\r\n""" % (appid, base64.b64encode(hmac.new(apikey, appid, 'md5').digest()))
    #print('answer:', _init1, flush=True)
    _conn._send(_init1)
    _init2 = _conn._read(_conn._handle, 256).split()
    if b'101' != _init2[1]:
        raise AuthenticationError('Digest sent was rejected1', _init2[1])
    _conn.ok = True
    #print('Handshake1', flush=True)
    return

    message = connection.recv_bytes(256)         # reject large message
    assert message[:len(CHALLENGE)] == CHALLENGE, 'message = %r' % message
    message = message[len(CHALLENGE):]
    digest = hmac.new(authkey, message, 'md5').digest()
    connection.send_bytes(digest)
    response = connection.recv_bytes(256)        # reject large message
    if response != WELCOME:
        raise AuthenticationError('digest sent was rejected')

multiprocessing.connection.deliver_challenge = deliver_challenge
multiprocessing.connection.answer_challenge = answer_challenge

"""
def address_type(address):
    '''
    Return the types of the address

    This can be 'AF_INET', 'AF_UNIX', or 'AF_PIPE'
    '''
    return 'AF_INET'
    if type(address) in (tuple, list):
        return 'AF_INET'
    elif type(address) is str and address.startswith('\\\\'):
        return 'AF_PIPE'
    elif type(address) is str:
        return 'AF_UNIX'
    else:
        raise ValueError('address type of %r unrecognized' % address)
multiprocessing.connection.address_type = address_type

def SocketClient(address):
    '''
    Return a connection object connected to the socket given by `address`
    '''
    family = address_type(address)
    with socket.socket( getattr(socket, family) ) as s:
        s.setblocking(True)
        s.connect(tuple(address) if type(address) == list else address)
        return Connection(s.detach())
multiprocessing.connection.SocketClient = SocketClient
"""

def AutoProxy(token, serializer, manager=None, authkey=None,
              exposed=None, incref=True, manager_owned=None):
    '''
    Return an auto-proxy for `token`
    '''
    _Client = listener_client[serializer][1]

    if exposed is None:
        conn = _Client(token.address, authkey=authkey)
        try:
            exposed = dispatch(conn, None, 'get_methods', (token,))
        finally:
            conn.close()

    if authkey is None and manager is not None:
        authkey = manager._authkey
    if authkey is None:
        authkey = process.current_process().authkey

    ProxyType = MakeProxyType('AutoProxy[%s]' % token.typeid, exposed)
    proxy = ProxyType(token, serializer, manager=manager, authkey=authkey,
                      incref=incref)
    proxy._isauto = True
    return proxy

multiprocessing.managers.AutoProxy = AutoProxy
"""
DictProxy._method_to_typeid_ = {
#    'apply_async': 'AsyncResult',
#    'map_async': 'AsyncResult',
#    'starmap_async': 'AsyncResult',
    'keys': 'Iterator',
    'values': 'Iterator'
    }
"""
