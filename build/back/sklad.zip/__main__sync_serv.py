# coding: utf-8

import sys, os, time

from ms71lib import rqlite
class MsRqliteDict(rqlite.RqliteDict):

    def __contains__(self, k):
        rows = self.query(["select k from %s where k='%s';" % (self._kv_name, (self._kv_prefix+k).replace("'", "''")),])
        #print('rows:', rows, flush=True)
        return rows and 'values' in rows[0]
    has_key = __contains__

    def copy(self, k=''):
        k = self._kv_prefix + k
        if k:
            rows = self.query(["select k,v from %s where k like '%s%%';" % (self._kv_name, k.replace("'", "''")),])
        else:
            rows = self.query(["select k,v from %s;" % self._kv_name])
        if rows:
            return dict(rows.pop(0).get('values') or ())
        return {}

    def keys(self, k=''):
        return super().keys(k=k) or []

    def values(self, k=''):
        return super().values(k=k) or []

    def items(self, k=''):
        return super().items(k=k) or []

#nm = ''
#o = RqliteDict('http://localhost:4011', kv_name='', timeout=7)
#print(dir(o))
#print(o.status())
#print(o.keys())
#exit(0)

from multiprocessing import freeze_support
from multiprocessing.managers import State, BaseManager, BaseProxy, SyncManager, \
    Namespace, NamespaceProxy, ListProxy, DictProxy, pool, PoolProxy, EventProxy, \
    AcquirerProxy, ConditionProxy, BarrierProxy

from multiprocessing import context, process
#process.current_process().authkey = b'masterkey'
#print(process.current_process().authkey)

import operator
import threading
from collections import defaultdict
import queue, threading

import __main__sync_helper as helper

##

class Foo:
    def f(self):
        print('you called Foo.f()')
    def g(self):
        print('you called Foo.g()')
    def _h(self):
        print('you called Foo._h()')

# A simple generator function
def baz():
    for i in range(10):
        yield i*i

# Proxy type for generator objects
class GeneratorProxy(BaseProxy):
    _exposed_ = ['__next__']
    def __iter__(self):
        return self
    def __next__(self):
        return self._callmethod('__next__')

# Function to return the operator module
def get_operator_module():
    return operator

from importlib import reload
def get_module(name, fg_reload=False):
    m = sys.modules.get(name)
    if not m:
        m = __import__(name, fromlist=['',])
    if fg_reload:
        m = reload(m)
    return m

#Global.e = threading.Event()
#print(dir(Global))
#print(Global.__str__())
#Global.__list__ = lambda: tuple(n for n in Global.__dict__.keys() if not n.startswith('_'))
#print(Global.__list__())
#print(Global.__str__())
#print(111)
#print(dir(NamespaceProxy))
#print('_exposed_:', NamespaceProxy._exposed_)
#namespaceExposed
#print('__dict__:', Global.__dict__)
#print()
#Dict = {0: None, None: 0}
#Global = Namespace()
#Global.x = 10
##

namespaceExposed = list(NamespaceProxy._exposed_)
namespaceExposed += ['__str__',]
namespaceExposed = tuple(namespaceExposed)

class MsDict(dict):

    def items(self):
        return list(super().items())

    def keys(self):
        return list(super().keys())

    def values(self):
        return list(super().values())

class MsEvent(threading.Event):
    def __init__(self, **kwds):
        self.__d__= {}
        super().__init__()
        self.__d__.update(kwds)
        self.__getitem__ = self.__d__.__getitem__
        self.__setattr__ = self.__setitem__ = self.__d__.__setitem__
        self.__delattr__ = self.__delitem__ = self.__d__.__delitem__
        self.__len__ = self.__d__.__len__
        self.__getattribute = self.__getattribute__
        self.__getattribute__ = self._getattribute

    """
    def __repr__(self):
        items = list(self.__dict__.items())
        temp = []
        for name, value in items:
            if not name.startswith('_'):
                temp.append('%s=%r' % (name, value))
        temp.sort()
        return '%s(%s)' % (self.__class__.__name__, ', '.join(temp))
    """
    def _getattribute(self, key):
        if key == '__d__':
            return self.__d__
        elif key in self.__d__:
            return self.__d__[key]
        return self.__getattribute(key)

    def keys(self):
        return list(self.__d__.keys())

    def set(self, **kwds):
        self.__d__.update(kwds)
        return super().set()

    def clear(self):
        self.__d__.clear()
        return super().clear()

    def get(self, timeout=None):
        if self.wait(timeout=timeout):
            return self.__d__


class MsEventProxy(BaseProxy):
    _exposed_ = ('keys','__getitem__','__setitem__','__delitem__','__len__','get', 'is_set','set','clear','wait','get', '__getattribute__','__setattr__','__delattr__')
    def keys(self):
        return self._callmethod('keys')
    def __getitem__(self, k):
        return self._callmethod('__getitem__', (k,))
    def __setitem__(self, k, v):
        return self._callmethod('__setitem__', (k, v))
    def __delitem__(self, k):
        return self._callmethod('__delitem__', (k,))
    def __len__(self):
        return self._callmethod('__len__')
    def is_set(self):
        return self._callmethod('is_set')
    def set(self, **kwds):
        return self._callmethod('set', (), kwds)
    def clear(self):
        return self._callmethod('clear')
    def wait(self, timeout=None):
        return self._callmethod('wait', (timeout,))
    def get(self, timeout=None):
        return self._callmethod('get', (timeout,))
    def __getattr__(self, key):
        if key[0] == '_':
            return object.__getattribute__(self, key)
        callmethod = object.__getattribute__(self, '_callmethod')
        return callmethod('__getattribute__', (key,))
    def __setattr__(self, key, value):
        if key[0] == '_':
            return object.__setattr__(self, key, value)
        callmethod = object.__getattribute__(self, '_callmethod')
        return callmethod('__setattr__', (key, value))
    def __delattr__(self, key):
        if key[0] == '_':
            return object.__delattr__(self, key)
        callmethod = object.__getattribute__(self, '_callmethod')
        return callmethod('__delattr__', (key,))

class MsManager(SyncManager):
    _dictNamespace = defaultdict(Namespace)
    _dictQueue = defaultdict(queue.Queue)
    _dictEvent = defaultdict(MsEvent)
    _dictLock = defaultdict(threading.Lock)
    _dictRLock = defaultdict(threading.RLock)
    _dictSemaphore = defaultdict(threading.Semaphore)
    _dictBoundedSemaphore = defaultdict(threading.BoundedSemaphore)
    _dictCondition = defaultdict(threading.Condition)
    _dictBarrier = defaultdict(threading.Barrier)
    _dictPool = defaultdict(pool.Pool)
    _dictList = defaultdict(list)
    _dictDict = defaultdict(MsDict)

    @classmethod
    def save(self, filename='1.bin'):
        #_f = context.get_spawning_popen
        #context.get_spawning_popen = lambda: True
        s = helper._ms71_dumps(self)
        #print(len(s))
        #print(type(s))
        with open(filename, 'wb') as f:
            f.write(s)
        #context.get_spawning_popen = _f

        return os.path.abspath(filename)

_cls = MsManager
MsManager.register('MsEvent', MsEvent, MsEventProxy)
MsManager.register('get_namespace', lambda nm=None: _cls._dictNamespace[nm], proxytype=NamespaceProxy, exposed=namespaceExposed)
MsManager.register('get_queue', lambda nm=None: _cls._dictQueue[nm])
MsManager.register('get_event', lambda nm=None: _cls._dictEvent[nm], MsEventProxy)
MsManager.register('get_lock', lambda nm=None: _cls._dictLock[nm], AcquirerProxy)
MsManager.register('get_rlock', lambda nm=None: _cls._dictRLock[nm], AcquirerProxy)
MsManager.register('get_semaphore', lambda nm=None: _cls._dictSemaphore[nm], AcquirerProxy)
MsManager.register('get_bounded_semaphore', lambda nm=None: _cls._dictBoundedSemaphore[nm], AcquirerProxy)
MsManager.register('get_condition', lambda nm=None: _cls._dictCondition[nm], ConditionProxy)
#MsManager.register('get_barrier', lambda nm=None: _cls._dictBarrier[nm], BarrierProxy)
MsManager.register('get_pool', lambda nm=None: _cls._dictPool[nm], PoolProxy)
MsManager.register('get_list', lambda nm=None: _cls._dictList[nm], ListProxy)
#MsManager.register('get_dict', lambda nm=None: _cls._dictDict[nm], DictProxy)
def _getRqliteDect(nm=None, kv_text=False):
    if nm in _cls._dictDict:
        return _cls._dictDict[nm]
    if kv_text:
        o = MsRqliteDict('http://localhost:4011', kv_name=nm if nm else '', timeout=3)
        _cls._dictDict[nm] = o
        return o
    else:
        return _cls._dictDict[nm]
MsManager.register('get_dict', _getRqliteDect, DictProxy)
MsManager.register('dict', MsDict, DictProxy)
try:
    manager
except:
    manager = None  # MsManager(('127.0.0.1', 50002), serializer='ms71')
MsManager.register('save', lambda filename='1.bin': MsManager.save())
MsManager.register('get_module', get_module)


#class RqliteDict(object):
#def __init__(self, url, kv_name='', kv_prefix='', api_key='', host_name='', timeout=None):


# register the Foo class; make `f()` and `g()` accessible via proxy
#MyManager.register('Foo1', Foo)

# register the Foo class; make `g()` and `_h()` accessible via proxy
#MyManager.register('Foo2', Foo, exposed=('g', '_h'))

# register the generator function baz; use `GeneratorProxy` to make proxies
#MyManager.register('baz', baz, proxytype=GeneratorProxy)

# register get_operator_module(); make public functions accessible via proxy
#MyManager.register('operator', get_operator_module)

"""
SyncManager.register('Queue', queue.Queue)
SyncManager.register('JoinableQueue', queue.Queue)
SyncManager.register('Event', threading.Event, EventProxy)
SyncManager.register('Lock', threading.Lock, AcquirerProxy)
SyncManager.register('RLock', threading.RLock, AcquirerProxy)
SyncManager.register('Semaphore', threading.Semaphore, AcquirerProxy)
SyncManager.register('BoundedSemaphore', threading.BoundedSemaphore,
                     AcquirerProxy)
SyncManager.register('Condition', threading.Condition, ConditionProxy)
SyncManager.register('Barrier', threading.Barrier, BarrierProxy)
SyncManager.register('Pool', pool.Pool, PoolProxy)
SyncManager.register('list', list, ListProxy)
SyncManager.register('dict', dict, DictProxy)

SyncManager.register('Value', Value, ValueProxy)
SyncManager.register('Array', Array, ArrayProxy)

SyncManager.register('Namespace', Namespace, NamespaceProxy)

# types returned by methods of PoolProxy
SyncManager.register('Iterator', proxytype=IteratorProxy, create_method=False)
SyncManager.register('AsyncResult', create_method=False)
"""

def get_manager(authkey=None):
    global manager
    if manager:
        return manager
    if not authkey:
        authkey = b'noname.default:masterkey'
    process.current_process().authkey = authkey
    manager = MsManager(('127.0.0.1', 0), serializer='ms71')
    return manager


##

def test():
    global manager
    #import helper
    process.current_process().authkey = b'sklad.antey:masterkey'
    #with MsManager(('127.0.0.1', 50002), serializer='ms71') as m:
    #    manager = m
    #    print(dir(manager))
    #    input('>>>')
    #return

    manager = MsManager(('127.0.0.1', 0), serializer='ms71')
    print(dir(manager))
    #manager.save()
    #_f = context.get_spawning_popen
    #context.get_spawning_popen = lambda: True
    #s = helper._ms71_dumps(manager)
    #print(len(s))
    #print(type(s))
    #with open('1.bin', 'wb') as f:
    #    f.write(s)
    #context.get_spawning_popen = _f

    s = manager.get_server()
    print(dir(s))
    print(s.address)
    print(s.authkey)
    #manager._state.value = State.STARTED

    #print(manager.save())

    s.serve_forever()
    return


    manager.start()
    print('-' * 20)

    f1 = manager.Foo1()
    f1.f()
    f1.g()
    assert not hasattr(f1, '_h')
    assert sorted(f1._exposed_) == sorted(['f', 'g'])

    print('-' * 20)

    f2 = manager.Foo2()
    f2.g()
    f2._h()
    assert not hasattr(f2, 'f')
    assert sorted(f2._exposed_) == sorted(['g', '_h'])

    print('-' * 20)

    it = manager.baz()
    for i in it:
        print('<%d>' % i, end=' ')
    print()

    print('-' * 20)

    op = manager.operator()
    print('op.add(23, 45) =', op.add(23, 45))
    print('op.pow(2, 94) =', op.pow(2, 94))
    print('op._exposed_ =', op._exposed_)
    ns = manager.get_global()
    print(ns)

##

if __name__ == '__main__':
    freeze_support()
    test()
