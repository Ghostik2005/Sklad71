# coding: utf-8

import sys, os, time

__appname__ = 'sklad-dev'
__version__ = '20.204.1540'

__profile__ = ''  # do not edit
log = sys.log

import random
import socket, hashlib, shutil
import subprocess as sp
import multiprocessing as mp
from multiprocessing import dummy as tp
from pprint import pprint

import requests
requests.packages.urllib3.disable_warnings()
import cherrypy

zip_root = os.path.dirname(os.path.abspath(__file__))
if not os.path.isfile(zip_root):
    zip_root = None
import mimetypes
from cherrypy.lib import cptools, httputil, file_generator_limited
import zipfile
_assets = None
def serve_file(path, content_type=None, disposition=None, name=None, debug=False):

    response = cherrypy.serving.response

    global zip_root, _assets
    if path.startswith(zip_root):
        _file = path[len(zip_root)+1:].replace('\\', '/')
        path = ''
        if True:
            with zipfile.ZipFile(zip_root, "r") as zf:
                _gz = False
                if _assets is None:
                    _assets = set(filter(lambda x: x and x.startswith("assets") and x[-1] != '/', zf.namelist()))
                zi = None
                if _file in _assets:
                    zi = zf.getinfo(_file)
                elif _file + '.gz' in _assets:
                    _gz = True
                    zi = zf.getinfo(_file + '.gz')
                else:
                    raise cherrypy.NotFound()
                if hasattr(zi, "filename"):
                    pass
                else:
                    raise cherrypy.NotFound()
                dt = list(zi.date_time); dt.append(0); dt.append(0); dt.append(1)
                dt = time.mktime(tuple(dt))
                response.headers['Last-Modified'] = httputil.HTTPDate(dt)
                cptools.validate_since()
                if content_type is None:
                    # Set content-type based on filename extension
                    ext = ''
                    i = _file.rfind('.')
                    if i != -1:
                        ext = _file[i:].lower()
                    content_type = mimetypes.types_map.get(ext, None)
                if content_type is not None:
                    response.headers['Content-Type'] = content_type
                content_length = zi.file_size
                if _gz:
                    response.headers['Content-Encoding'] = 'gzip'
                    fileobj = zf.open(_file + '.gz')
                else:
                    fileobj = zf.open(_file)
                return cherrypy.lib.static._serve_fileobj(fileobj, content_type, content_length, debug=debug)
    raise cherrypy.NotFound()
if zip_root:
    cherrypy.lib.static.serve_file = serve_file


def init_manager(NewManager):
    global __appname__, __version__, __profile__
    log('MANAGER', 'INIT')
    manager = NewManager()
    return manager


def init_master():
    global __appname__, __version__, __profile__
    log('MASTER', kind='INIT')

    #from __main__sync_serv import MsManager  # Общие данные для дочерних процессов
    #kv = MsManager._dictDict[None]
    #kv[333] = 444

    #for nm in ('file_conf',):
    #    if not sys.conf.get('file_conf'):
    #        log('%s not defined or empty' %nm, 'config')


def init_handler(ClassHandler):
    global __appname__, __version__, __profile__
    wid = sys.conf['worker_id']
    log('HANDLER%s' % wid, 'INIT')

    import mods
    #m, rpc = None, None
    #v, v2  = '', ''
    #with sys.manager.get_rlock('modules'):
    #    m = sys.manager.get_module('mods')
    #    v = m.version()
    #    _fg = v < '00.000.0002'
    #    if _fg:
    #        m = sys.manager.get_module('mods', fg_reload=_fg)
    #    rpc = sys.manager.get_module('mods.rpc', fg_reload=_fg)

    handler = ClassHandler()
    handler.register_multicall_functions()
    handler.register_introspection_functions()
    handler.register_function(lambda *a, **kw: {'appname': __appname__, 'version': __version__, 'profile': __profile__}, 'system.appinfo')

    handler.register_function(test, 'system.test')
    handler.register_function(lambda *a, **kw: ["echo", a, kw], 'echo')


    handler.register_instance(mods.sklad.SKLAD(), allow_dotted_names=True)
    # handler.register_instance(MyApi(), allow_dotted_names=True)

    cherrypy.config.update({
        'environment': 'production',
        'log.screen': True,
        'engine.autoreload.on': False,
    })

    cherrypy.tree.graft(handler.handle_request, '/')
    conf = {
        '/': {'tools.staticdir.on': True,
            'tools.staticdir.root': os.path.join(os.path.dirname(os.path.abspath(__file__)), 'assets'),
            'tools.staticdir.dir': '',
         }
    }
    cherrypy.tree.mount(Root(), '/ui', config=conf)
    #cherrypy.tree.graft(application, "/")
    return handler  # or application or None

# Our CherryPy application
class Root(object):
    @cherrypy.expose
    def index(self):
        return "Hello, World!"

import threading
def test(*a, **kw):
    print('test:', a, kw)
    th = threading.current_thread()
    pid = os.getpid()
    #r = []
    for i in range(30):
        s = 'data: [%05d %s]\nid: %s\n\n' % (pid, th.name, time.strftime('%Y-%m-%d %H:%M:%S\n\n'))
        #r.append(s)
        try:
            yield s.encode()
        except:
            log('stop yield')
            break
        log(s)
        time.sleep(1)
    #return ''.join(r)


class MyApi(object):

    def __init__(self):
        self.sync = MyApi2()

    # выводим список доступных методов "по своему"
    def _listMethods(self):
        r = set(self._list_public_methods(self))
        r.discard('sync')
        r |= set(self._list_public_methods(self.sync, 'sync'))
        return sorted(r)

    def _list_public_methods(self, obj, alias=None):
        return ['%s.%s' % (alias, member) if alias else member for member in dir(obj)
                    if not member.startswith('_')]  # and
        #                callable(getattr(obj, member))]

    def div(self, x, y):
        return float(x) / float(y)

class MyApi2(object):

    def __init__(self):
        try:
            self.kv = sys.manager.get_dict()
        except:
            time.sleep(random.random())
            self.kv = sys.manager.get_dict()

        setattr(self.kv, 'set', self.kv.__setitem__)
        #setattr(self.kv, '__call__', lambda self, *a, **kw: True)
        if sys.rmanager:
            try:
                self.rkv = sys.rmanager.get_dict()
            except:
                self.rkv = sys.rmanager.get_dict()
                time.sleep(random.random())
            setattr(self.rkv, 'set', self.rkv.__setitem__)

    def __call__(self, *a, **kw):
        return a, kw

    def div2(self, x, y):
        return float(x) / float(y)

