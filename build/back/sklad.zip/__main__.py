#!/ms71/mini/bin/python
# coding: utf-8

import sys, os

try:
    sys.FG_RELOAD
except:
    sys.FG_RELOAD = False
try:
    CONF
except:
    CONF = None

def start():
    global CONF
    _srcname = os.path.abspath(__file__)
    _dirname = os.path.dirname(_srcname)
    sys.path[0] = _dirname
    try:
        sys.conf
    except:
        sys.conf = {}
    try:
        if CONF and CONF != sys.conf:
            sys.conf.update(CONF)
    except:
        pass
    CONF = sys.conf

    import json
    for k in tuple(os.environ.keys()):
        if k.isdigit():
            v = os.environ.pop(k)
            if v[0] == '{':
                CONF.update(json.loads(v))
            else:
                k, v = v.split('=', 1)
                CONF[k] = json.loads(v) if v[0] == '{' else  v
        elif k.startswith('a.'):
            k, v = k[2:], os.environ.pop(k)
            CONF[k] = json.loads(v) if v[0] == '{' else  v

    for v in sys.argv[1:]:
        if v[0] == '{':
            CONF.update(json.loads(v))
        else:
            k, v = v.split('=', 1)
            CONF[k] = json.loads(v) if v[0] == '{' else  v

    import __main__serv
    __main__serv.main(fg_reload=False)
    if sys.FG_RELOAD:
        sys.exit(1)


if '__main__' == __name__:
    import multiprocessing as mp
    mp.freeze_support()
    mp.set_start_method('spawn')
    start()
