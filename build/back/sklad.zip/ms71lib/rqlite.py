# coding: utf-8

import sys, os, time, json

import requests
requests.packages.urllib3.disable_warnings()

from . import PY3, ServerProxy, MultiCall, client
from .client import ProtocolError
if PY3:
    raw_input = input
    from urllib.parse import quote_plus, unquote_plus, urlencode, urlparse
else:
    from urllib import quote_plus, unquote_plus, urlencode
    from urlparse import urlparse
import threading


class RqliteDict(object):

    def __init__(self, url, kv_name='', kv_prefix='', api_key='', host_name='', timeout=None):
        self._lock = threading.RLock()
        self._url = urlparse(url)
        self._api_key = api_key
        self._timeout = timeout
        #print(self._url.geturl())
        #print(dir(self._url))
        if kv_name:
            self._kv_name = kv_name
        else:
            self._kv_name = 'kv'
        self._kv_prefix = kv_prefix
        self._rpc = ServerProxy(url, verbose=False, api_key=api_key, host_name=host_name)
        self._req = self._rpc('request')
        #self._handler = self._rpc('handler')
        self._transport = self._rpc('transport')
        self._transport.encode_threshold = 10*1024*1024  # a common MTU
        #self._transport.encode_threshold = 1400  # a common MTU

        if timeout:
            self._transport._timeout = timeout
        #print(1111, dir(self._handler))
        #print(2222, dir(self._transport))
        #sys.exit(0)

        self.fg_init_err = True
        self._sql_create_kv = "CREATE TABLE IF NOT EXISTS %s(k TEXT PRIMARY KEY, v TEXT) WITHOUT ROWID;" % self._kv_name
        #self.fg_init_err = 'error' in self._cmd([self._sql_create_kv,])[0]
        try:
            #pass
            self.fg_init_err = 'error' in self._cmd([self._sql_create_kv,])[0]
        except:
            pass

    def cmd(self, x):
        if self.fg_init_err:
            self.fg_init_err = 'error' in self._cmd([self._sql_create_kv,])[0]
        self._cmd(x)

    def _cmd(self, x):
        with self._lock:
            #print('_cmd', x)
            #sys.stdout.flush()
            if len(x) > 1:
                return self._req(json.dumps(x).encode('utf8'), self._url.path + '/db/execute?transaction').pop('results')
            else:
                return self._req(json.dumps(x).encode('utf8'), self._url.path + '/db/execute').pop('results')

    def query(self, q):
        with self._lock:
            #print('query', q)
            #sys.stdout.flush()
            if self.fg_init_err:
                self.fg_init_err = 'error' in self._cmd([self._sql_create_kv,])[0]
            return self._req(json.dumps(q).encode('utf8'), self._url.path + '/db/query').pop('results')

    def fetch(self, q):
        with self._lock:
            #print('flush', q)
            #sys.stdout.flush()
            if self.fg_init_err:
                self.fg_init_err = 'error' in self._cmd([self._sql_create_kv,])[0]
            return self._req(json.dumps(q).encode('utf8'), self._url.path + '/db/query?level=none').pop('results')  # .pop(0).get('values', [])

    def close(self):
        with self._lock:
            self._req = None
            if self._rpc:
                self._rpc('close')()
            self._rpc = None

    def status(self):
        try:
            if self._api_key:
                r = requests.get(self._url.geturl() + '/status', headers={'X-API-Key': self._api_key}, timeout=self._timeout)
            else:
                r = requests.get(self._url.geturl() + '/status', headers={'X-API-Key': self._api_key}, timeout=self._timeout)
            return r.json()
        finally:
            r.close()

    def __del__(self):
        try: self.close()
        except: pass

    def __setitem__(self, k, v):
        self.cmd(["replace into %s(k,v)values('%s','%s')" % (self._kv_name, (self._kv_prefix+k).replace("'", "''"), v.replace("'", "''")),])

    def __getitem__(self, k):
        rows = self.query(["select v from %s where k='%s';" % (self._kv_name, (self._kv_prefix+k).replace("'", "''")),])
        if rows:
            row = rows.pop(0)
            if 'values' in row:
                return row['values'][0][0]

    def __delitem__(self, k):
        self.cmd(["delete from %s where k='%s';" % (self._kv_name, (self._kv_prefix+k).replace("'", "''")),])

    def __iter__(self):
        for k in self.keys():
            yield k

    def clear(self, k=''):
        k = self._kv_prefix + k
        if k:
            self.cmd(["delete from %s where k like '%s%%';" % (self._kv_name, k.replace("'", "''")),])
        else:
            self.cmd(["delete from %s;" % (self._kv_name)])

    def get(self, k, v=None):
        rows = self.query(["select v from %s where k='%s';" % (self._kv_name, (self._kv_prefix+k).replace("'", "''")),])
        if rows:
            row = rows.pop(0)
            if 'values' in row:
                return row['values'][0][0]
        return v

    def pop(self, k, v=None):
        rows = self.query(["select v from %s where k='%s';" % (self._kv_name, (self._kv_prefix+k).replace("'", "''")),])
        if rows:
            row = rows.pop(0)
            if 'values' in row:
                self.cmd(["delete from %s where k='%s';" % (self._kv_name, (self._kv_prefix+k).replace("'", "''")),])
                return row['values'][0][0]
        return v

    def popitem(self):
        if self._kv_prefix:
            rows = self.query(["select k,v from %s where k like '%s%%' limit 1;" % (self._kv_name, self._kv_prefix.replace("'", "''")),])
        else:
            rows = self.query(["select k,v from %s limit 1;" % self._kv_name,])
        if rows:
            row = rows.pop(0)
            if 'values' in row:
                self.cmd(["delete from %s where k='%s';" % (self._kv_name, row['values'][0][0].replace("'", "''")),])
                return row['values'][0]

    def keys(self, k=''):
        k = self._kv_prefix + k
        if k:
            rows = self.query(["select k from %s where k like '%s%%';" % (self._kv_name, k.replace("'", "''")),])
        else:
            rows = self.query(["select k from %s;" % self._kv_name,])
        if rows:
            row = rows.pop(0)
            if 'values' in row:
                return [v[0] for v in row['values']]

    def values(self, k=''):
        k = self._kv_prefix + k
        if k:
            rows = self.query(["select v from %s where k like '%s%%';" % (self._kv_name, k.replace("'", "''")),])
        else:
            rows = self.query(["select v from %s;" % self._kv_name,])
        if rows:
            row = rows.pop(0)
            if 'values' in row:
                return [v[0] for v in row['values']]

    def items(self, k=''):
        k = self._kv_prefix + k
        if k:
            rows = self.query(["select k,v from %s where k like '%s%%';" % (self._kv_name, k.replace("'", "''")),])
        else:
            rows = self.query(["select k,v from %s;" % self._kv_name])
        if rows:
            return rows.pop(0).get('values')

    def __len__(self):
        if self._kv_prefix:
            rows = self.query(["select count(*) from %s where k like '%s%%';" % (self._kv_name, self._kv_prefix.replace("'", "''")),])
        else:
            rows = self.query(["select count(*) from %s;" % self._kv_name])
        while rows:
            row = rows.pop(0)
            if 'values' in row:
                return row['values'][0][0]
        return 0

    def update(self, *a, **F):
        """
        D.update([E, ]**F) -> None.  Update D from dict/iterable E and F.
        If E present and has a .keys() method, does:     for k in E: D[k] = E[k]
        If E present and lacks .keys() method, does:     for (k, v) in E: D[k] = v
        In either case, this is followed by: for k in F: D[k] = F[k]
        """
        q = []
        for E in a:
            if hasattr(E, 'keys'):
                q.extend("replace into %s(k,v)values('%s','%s');" % (self._kv_name, (self._kv_prefix+k).replace("'", "''"),  E[k].replace("'", "''")) for k in E)
            else:
                q.extend("replace into %s(k,v)values('%s','%s');" % (self._kv_name, (self._kv_prefix+kv[0]).replace("'", "''"),  kv[1].replace("'", "''")) for kv in E)
        if F:
            q.extend("replace into %s(k,v)values('%s','%s');" % (self._kv_name, (self._kv_prefix+k).replace("'", "''"),  F[k].replace("'", "''")) for k in F)
        if q:
            self.cmd(q)

    def set(self, k, v):
        self.__setitem__(k, v)
        if k in self:
            return k

    def delete(self, k):
        return self.__delitem__(k)

    def length(self):
        return self.__len__()


def test():
    print('test:%s' % __file__)

if '__main__' == __name__:
    test()
