# This directory is a Python package.

import sys

__all__ = ['PY3', 'client', 'server', 'sse', 'ServerProxy', 'MultiCall', 'gzip_encode', 'gzip_decode', 'SimpleJSONRPCDispatcher', 'rqlite', 'xml2dict', 'dict2xml']

PY3 = sys.version_info[0] > 2
from . import client
from . import server
from .client import sse
from .client import ServerProxy, MultiCall
from .client import gzip_encode, gzip_decode
from .server import SimpleJSONRPCDispatcher
from .rqlite import RqliteDict
from . import xmltodict
from .xmltodict import parse as xml2dict, unparse as dict2xml
